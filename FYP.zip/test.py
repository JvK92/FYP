import sys
import os
import getpass
import subprocess
import pexpect
#import Manager

suPass = sys.argv[1]

print suPass
