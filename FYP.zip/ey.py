import os

os.system("cat > sample.txt")
os.system("eyyy")
os.system('\004')
